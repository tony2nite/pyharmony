#####SENSOR####
from homeassistant.helpers.entity import Entity
from homeassistant.const import CONF_NAME, CONF_USERNAME, CONF_PASSWORD, CONF_PORT
import pyharmony
import logging




DOMAIN = 'harmony'
REQUIREMENTS = ['pyharmony>=0.2.0']
_LOGGER = logging.getLogger(__name__)
CONF_IP = 'ip'


def setup_platform(hass, config, add_devices, hubData, discovery_info=None):
    """Setup the sensor platform."""
    add_devices([HarmonySensor(hubData[CONF_NAME],
                 hubData[CONF_USERNAME],
                 hubData[CONF_PASSWORD],
                 hubData[CONF_IP],
                 hubData[CONF_PORT])])
    return True


class HarmonySensor(Entity):
    """Representation of a Sensor."""
    def __init__(self, name, username, password, ip, port):
        self._name = name
        self._email = username
        self._password = password
        self._ip = ip
        self._port = port

    @property
    def name(self):
        """Return the name of the sensor."""
        return self._name


    @property
    def state(self):
        """Return the state of the sensor."""
        return self.get_status()
    
            
    def get_status(self): 
        return pyharmony.ha_get_current_activity(self._email, self._password, self._ip, self._port)

        
   





